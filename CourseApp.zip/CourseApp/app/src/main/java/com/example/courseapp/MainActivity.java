
package com.example.courseapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {



    private Context context = this;
    private Class newsClass = news_class.class;
    private Class weatherClass=weather_class.class;
    private Class homeClass= MainActivity.class;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);




        BottomNavigationView bottom_nav=findViewById(R.id.bottom_nav);


        bottom_nav.setOnNavigationItemReselectedListener(nav_listner);
    }

    private BottomNavigationView.OnNavigationItemReselectedListener nav_listner=
            new BottomNavigationView.OnNavigationItemReselectedListener() {
                @Override
                public void onNavigationItemReselected(@NonNull MenuItem menuItem) {

                    switch (menuItem.getItemId()){
                        case R.id.news:
                            Intent intentToStartDetailActivity = new Intent(context, newsClass);


                            startActivity(intentToStartDetailActivity);
                            break;

                        case R.id.home_it:
                            break;
                        case R.id.weather:
                             intentToStartDetailActivity = new Intent(context, weatherClass);


                            startActivity(intentToStartDetailActivity);
                            break;
                    }
                    return;

                }
            };

}




